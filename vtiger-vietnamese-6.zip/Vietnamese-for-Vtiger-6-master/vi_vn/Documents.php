<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'Active' => 'Đang hoạt động',
	'Document No' => 'Mã tài liệu',
	'Documents' => 'Tài liệu',
	'Download Count' => 'Số lần tải về',
	'Download Type' => 'Định dạng tải về',
	'File Name' => 'Tên tập tin',
	'File Size' => 'Kích thước',
	'File Type' => 'Kiểu tập tin',
	'Folder Name' => 'Tên thư mục',
	'Last Modified By' => 'Lần cập nhật cuối',
	'LBL_ADD_FOLDER' => 'Thêm thư mục',
	'LBL_ADD_NEW_FOLDER' => 'Thêm thư mục mới',
	'LBL_ADD_RECORD' => 'Thêm tài liệu mới',
	'LBL_CHECK_FILE_INTEGRITY' => 'Kiểm tra tính toàn vẹn của tập tin',
	'LBL_DENIED_DOCUMENTS' => 'Tài liệu bị từ chối',
	'LBL_DESCRIPTION' => 'Mô tả',
	'LBL_DOCUMENTS_MOVED_SUCCESSFULLY' => 'Tài liệu đã được di chuyển thành công',
	'LBL_DOWNLOAD_FILE' => 'Tải tập tin',
	'LBL_EMAIL_FILE_AS_ATTACHMENT' => 'Gửi mail đính kèm tập tin',
	'LBL_EXTERNAL' => 'Nguồn ngoài',
	'LBL_FILE_AVAILABLE' => 'Tập tin có thể tải về',
	'LBL_FILE_INFORMATION' => 'Chi tiết tập tin',
	'LBL_FILE_NOT_AVAILABLE' => 'Tài liệu này không thể tải về',
	'LBL_FOLDER_DESCRIPTION' => 'Mô tả thư mục',
	'LBL_FOLDER_HAS_DOCUMENTS' => 'Vui lòng di chuyển các tài liệu từ thư mục này trước khi xóa',
	'LBL_FOLDER_NAME' => 'Tên thư mục',
	'LBL_FOLDERS' => 'Thư mục',
	'LBL_FOLDERS_LIST' => 'Danh sách thư mục',
	'LBL_INTERNAL' => 'Nguồn lưu',
	'LBL_MAX_UPLOAD_SIZE' => 'Kích thước tối đa có thể tải lên',
	'LBL_MOVE' => 'Di chuyển',
	'LBL_NOTE_INFORMATION' => 'Thông tin cơ bản',
	'LBL_RECORDS_LIST' => 'Danh sách tài liệu',
	'MB' => 'MB',
	'Note' => 'Ghi chú',
	'SINGLE_Documents' => 'Tài liệu',
	'Title' => 'Tiêu đề',
	'Version' => 'Phiên bản',
);

$jsLanguageStrings = array(
	'JS_ARE_YOU_SURE_YOU_WANT_TO_MOVE_DOCUMENTS_TO' => 'Bạn có chắc muốn di chuyển ta6o5 tin này',
	'JS_FOLDER' => 'thư mục',
	'JS_FOLDER_IS_NOT_EMPTY' => 'Thư mục đang có tập tin',
	'JS_MOVE_DOCUMENTS' => 'Di chuyển tài liệu',
	'JS_NEW_FOLDER' => 'Thư mục mới',
	'JS_NOT_ALLOWED' => 'không được phép',
	'JS_OPERATION_DENIED' => 'Hành động bị từ chối',
	'JS_SPECIAL_CHARACTERS' => 'Ký tự đặc biệt như',
);
