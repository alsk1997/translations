<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'ALVT' => 'Top Tổ chức',
	'CVLVT' => 'Số liệu chính',
	'GRT' => 'Phân bổ trong nhóm',
	'HDB' => 'Bảng điều khiển',
	'HLT' => 'Thống kê thẻ hỗ trợ',
	'Home'=> 'Trang chủ',
	'ILTI' => 'Thống kê Hóa đơn',
	'LTFAQ' => 'Các câu hỏi thường gặp',
	'OLTPO' => 'Thống kê Đơn đặt hàng',
	'OLTSO' => 'Thống kê bán hàng',
	'PA' => 'Nhiệm vụ đang chờ',
	'PLVT' => 'Top khách hàng tiềm năng',
	'QLTQ' => 'Top Báo giá',
	'UA' => 'Nhiệm vụ sắp tới',
);