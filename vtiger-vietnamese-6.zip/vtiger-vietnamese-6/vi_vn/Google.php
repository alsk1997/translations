<?php

/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'Address' => 'Địa chỉ',
	'Contact Name'=>'Tên liên hệ',
	'Description'=>'Mô tả',
	'Email'=>'Email',
	'Event Title'=>'Tên sự kiện',
	'EXTENTIONNAME' => 'Google',
	'LBL_ADDED' => 'Đã thêm',
	'LBL_DELETED' => 'Đã xóa',
	'LBL_MORE_GOOGLE' => 'Có nhiều bản ghi cần đồng bộ với Google',
	'LBL_MORE_VTIGER' => 'Có nhiều bản tin cần đổng bộ với DPS.CMS',
	'LBL_NOT_SYNCRONIZED' => 'Bạn chưa có đồng bộ nào',
	'LBL_REMOVE_SYNC' => 'Xóa đồng bộ',
	'LBL_SYNC_BUTTON' => 'Đồng bộ ngay',
	'LBL_SYNCRONIZED' => 'Đã đồng bộ dữ liệu',
	'LBL_UPDATED' => 'Đã cập nhận',
	'LBL_UPDATES_CRM' => 'Cập nhật trong CRM',
	'LBL_UPDATES_GOOGLE' => 'Cập nhật lên Google',
	'Map' => 'Bản đồ',
	'Mobile Phone'=>'Số điện thoại di động',
	'Start Date'=>'Bắt đầu ngày',
	'Until Date'=>'Cho đến ngày',
);

$jsLanguageStrings = array(
	'LBL_NOT_SYNCRONIZE' => 'Bạn chưa có đồng bộ dữ liệu nào',
	'LBL_SYNC_BUTTON' => 'Đồng bộ ngay',
	'LBL_SYNCRONIZING' => 'Đang đồng bộ dữ liệu....',
);
