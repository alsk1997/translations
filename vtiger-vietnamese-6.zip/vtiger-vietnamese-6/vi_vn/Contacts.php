<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'Assistant' => 'Tên người Đại diện',
	'Assistant Phone' => 'Số điện thoại người đại diện',
	'Birthdate' => 'Ngày sinh',
	'Contact Id' => 'ID',
	'Contact Image' => 'Hình đại diện',
	'Contacts' => 'Thông tin liên hệ',
	'Department' => 'Phòng ban',
	'Do Not Call' => 'Không liên lạc qua điên thoại',
	'Email' => 'Email chính',
	'Home Phone' => 'Điện thoại nhà riêng',
	'LBL_ADD_RECORD' => 'Thêm thông tin liên hệ',
	'LBL_CONTACT_INFORMATION' => 'Thông tin cơ bản',
	'LBL_COPY_MAILING_ADDRESS' => 'Sao chép địa chỉ nhận thư',
	'LBL_COPY_OTHER_ADDRESS' => 'Sao chép từ địa chỉ khác',
	'LBL_CUSTOMER_PORTAL_INFORMATION' => 'Thông tin truy cập cổng thông tin khách hàng',
	'LBL_IMAGE_INFORMATION' => 'Hình hồ sơ',
	'LBL_RECORDS_LIST' => 'Danh bạ',
	'Mailing City' => 'Mailing City',
	'Mailing Country' => 'Mailing Country',
	'Mailing Po Box' => 'Mailing P.O. Box',
	'Mailing State' => 'Mailing State',
	'Mailing Street' => 'Mailing Street',
	'Mailing Zip' => 'Mailing Zip',
	'Office Phone' => 'Số điện thoại văn phòng',
	'Other City' => 'Other City',
	'Other Country' => 'Other Country',
	'Other Phone' => 'Số điện thoại phụ',
	'Other Po Box' => 'Other P.O. Box',
	'Other State' => 'Other State',
	'Other Street' => 'Other Street',
	'Other Zip' => 'Other Zip',
	'Portal User' => 'Được phép truy cập cổng thông tin',
	'Reference' => 'Tham khảo',
	'Reports To' => 'Báo cáo cho',
	'Secondary Email' => 'Email phụ',
	'SINGLE_Contacts' => 'Thông tin liên hệ',
    'Support End Date'   => 'Ngày kết thúc hỗ trợ',
    'Support Start Date' => 'Ngày bắt đầu hỗ trợ',
	'Title' => 'Danh xưng',
	'User List'=>'Danh sách nhân viên',
	
	//Added for Picklist Values
	'Dr.'=>'Dr.',
	'Mr.'=>'Mr.',
	'Mrs.'=>'Mrs.',
	'Ms.'=>'Ms.',
	'Prof.'=>'Prof.',
);

$jsLanguageStrings = array(
 );
