<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'Date & Time Sent' => 'Ngày gửi',
	'Emails' => 'Emails',
	'LBL_ADD_BCC' => 'Thêm địa chỉ Bcc',
	'LBL_ADD_CC' => 'Thêm địa chỉ Cc',
	'LBL_ATTACHMENT' => 'Đính kèm',
	'LBL_BCC' => 'Bcc',
	'LBL_BROWSE_CRM' => 'Duyệt CRM',
	'LBL_CC' => 'Cc',
	'LBL_COMPOSE_EMAIL' => 'Soạn thư',
	'LBL_DESCRIPTION' => 'Mô tả',
        'LBL_MAIL_DATE'  => 'Ngày', 
	'LBL_DRAFTED_ON' => 'Bản nháp lưu ngày',
        'LBL_DRAFT'=>'Bản nháp', 
        'LBL_ATTACHED'=>'Đã đính kèm', 
	'LBL_EMAIL_INFORMATION' => 'Thông báo email',
	'LBL_EXCEEDED' => 'Vượt quá',
	'LBL_FORWARD' => 'Chuyển tiếp',
	'LBL_FROM' => 'Từ',
	'LBL_GO_TO_PREVIEW' => 'Xem trước',
	'LBL_INFO' => 'Thông tin',
	'LBL_MAX_UPLOAD_SIZE' => 'Kích thước tối đa của tập tin tải lên',
	'LBL_OWNER' => 'Chủ thể',
	'LBL_PRINT' => 'In',
	'LBL_SAVE_AS_DRAFT' => 'Lưu thư nháp',
	'LBL_SELECT_EMAIL_IDS' => 'Chọn địa chỉ email',
	'LBL_SELECT_EMAIL_TEMPLATE' => 'Chọn địa chỉ email',
	'LBL_SEND' => 'Gửi thư',
	'LBL_SENT_ON' => 'Ngày gửi',
	'LBL_SUBJECT' => 'Tiêu đề',
	'LBL_TO' => 'Gửi đến',
	'SINGLE_Emails' => 'Email',
	'Time Start' => 'Giờ gửi',
);
