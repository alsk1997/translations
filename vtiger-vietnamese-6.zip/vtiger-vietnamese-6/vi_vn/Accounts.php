<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	'Account Name' => 'Tên tổ chức',
	'Account No' => 'Mã tổ chức',
	'Accounts' => 'Tổ chức',
	'Analyst'=>'Nhà phân tích',
	'Competitor'=>'Đối thủ cạnh tranh',
	'Customer'=>'Khách hàng',
	'Email' => 'Email chính',
	'Employees' => 'Nhân lực',
	'industry' => 'Ngành nghề',
	'Integrator'=>'Nhà tích hợp', //Cổ đông
	'Investor'=>'Nhà đầu tư',
	'LBL_ACCOUNT_INFORMATION' => 'Chi tiết tổ chức',
	'LBL_ADD_RECORD' => 'Thêm tổ chức',
	'LBL_COPY_BILLING_ADDRESS' => 'Copy Billing Address',
	'LBL_COPY_SHIPPING_ADDRESS' => 'Copy Shipping Address',
	'LBL_DUPLICATES_EXIST' => 'Tên tổ chức này đã tồn tại',
	'LBL_END_DATE' => 'Ngày kết thúc',
	'LBL_RECORDS_LIST' => 'Danh sách tổ chức',
	'LBL_SHOW_ACCOUNT_HIERARCHY' => 'Phân cấp tổ chức',
	'LBL_START_DATE' => 'Ngày bắt đầu',
	'Member Of' => 'Thành viên của',
	'Other Email' => 'Email phụ',
	'Other Phone' => 'Số điện thoại phụ',
	'Ownership' => 'Chủ thể',
	'Phone' => 'Số điện thoại chính',
	'Press'=>'Nhà báo',
	'Prospect'=>'Triển vọng',
	'Reseller'=>'Đại lý bán hàng',
	'SIC Code' => 'SIC Code',
	'SINGLE_Accounts' => 'Tổ chức',
	'Ticker Symbol' => 'Đánh dấu',
	'Website' => 'Website',
);

$jsLanguageStrings = array(
	'JS_DUPLICTAE_CREATION_CONFIRMATION' => 'Tổ chức này đã có trong hệ thống.Bạn có muốn tạo trùng tên tổ chức?',
	'LBL_DELETE_CONFIRMATION' => 'Xóa tổ chức này đồng nghĩa với việc xóa các tiềm năng và báo giá. Bạn có muốn xóa tổ chức này không?',
	'LBL_MASS_DELETE_CONFIRMATION' => 'Xóa các tổ chức này đồng nghĩa với việc xóa các tiềm năng và báo giá. Bạn có muốn xóa các tổ chức được chọn này không?',
	'LBL_RELATED_RECORD_DELETE_CONFIRMATION' => 'Bạn có chắc muốn xóa bản ghi này?',
);
